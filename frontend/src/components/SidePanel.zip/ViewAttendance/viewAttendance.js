import React, { useState } from "react";
import { ProSidebarProvider } from "react-pro-sidebar";
import { StudentSidePanel } from "../SidePanel/SidePanel";
import Calendar from 'react-calendar';
import './viewAttendance.css';

function ViewAttendance() {
    const [value, onChange] = useState(new Date());


    return (
        <div id="ViewAttendance">
            <div id="sidePanel">
                <ProSidebarProvider>
                    <StudentSidePanel />
                </ProSidebarProvider>
            </div>
            <div className="studentAttendance">
                <h1 className="attendanceHeading">Attendance</h1>
                <div className="calendar">
                    <Calendar
                        onChange={onChange}
                        value={value}
                    />
                </div>
            </div>
        </div>
    );
}

export default ViewAttendance;